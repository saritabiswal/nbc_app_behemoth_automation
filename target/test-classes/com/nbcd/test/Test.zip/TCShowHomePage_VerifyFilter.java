package com.nbcd.Test;

import java.io.IOException;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.codoid.products.exception.FilloException;
import com.nbcd.GenericLib.Extent_Reports;
import com.nbcd.Pages.PGShowHomePage_043VerifyFaceBookTags;
import com.nbcd.Pages.PGShowHomePage_VerifyFilter;
public class TCShowHomePage_VerifyFilter  extends Extent_Reports
{
	public WebDriver driver;
	
	
	@Test(groups="TCShowHomePage_VerifyFilter")
	
	@Parameters({ "Browser"})
	public void metaTags(String Browser) throws InterruptedException, FilloException, IOException 
	 {
		
		PGShowHomePage_VerifyFilter objSP;
		try {
			objSP = new PGShowHomePage_VerifyFilter(Browser);
			objSP.VerifyFilter();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		

	}
				
	

}


	
	

