package com.nbcd.Test;

import java.io.IOException;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.codoid.products.exception.FilloException;
import com.nbcd.GenericLib.Extent_Reports;
import com.nbcd.Pages.PGPhotosLandingPage;
import com.nbcd.Pages.PGSchedulePage;
import com.nbcd.Pages.PGShowHomePage_043VerifyTwitterTags;
import com.nbcd.Pages.PGShowHomePage_VerifyThe300x250_Display_Ad;
public class TCPhotoLandingPage  extends Extent_Reports
{
	public WebDriver driver;
	
	
	@Test(groups="TCPhotoLandingPage")
	
	@Parameters({ "Browser"})
	 public void VerifyPhotoLandingPage(String Browser) throws InterruptedException, FilloException, IOException 
	 {
		
		PGPhotosLandingPage objSP;
		try {
			objSP = new PGPhotosLandingPage(Browser);
			objSP.Verify_PhotoLandingPage();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		

	}
				
	

}


	
	

