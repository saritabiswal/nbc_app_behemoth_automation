package com.nbcd.Test;

import java.io.IOException;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.codoid.products.exception.FilloException;
import com.nbcd.GenericLib.Extent_Reports;
import com.nbcd.Pages.PGShowHomePage_043VerifyFacebook_SNLTags;
public class TCShowHomePage_043VerifyFaceBook_SNLTags  extends Extent_Reports
{
	public WebDriver driver;
	
	
	@Test(groups="TCShowHomePage")
	
	@Parameters({ "Browser"})
	public void FB_SNLTags(String Browser) throws InterruptedException, FilloException, IOException 
	 {
		
		PGShowHomePage_043VerifyFacebook_SNLTags objSP;
		try {
			objSP = new PGShowHomePage_043VerifyFacebook_SNLTags(Browser);
			objSP.VerifyFB_SNLTags();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		

	}
				
	

}


	
	

