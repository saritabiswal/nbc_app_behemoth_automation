package com.nbcd.Test;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.codoid.products.exception.FilloException;
import com.nbcd.GenericLib.Extent_Reports;
import com.nbcd.Pages.PGContactUs;

public class TCContactUsCreateRequest extends Extent_Reports 
{
	public WebDriver driver;
	
	
	
	@Test(groups="TCContactUsPage")
	@Parameters({ "Browser"})
	 public void CreateContactUsRequest(String Browser) throws InterruptedException, FilloException, IOException 
	 {

		PGContactUs objHP = new PGContactUs(Browser);
		
		objHP.CreateContactUsRequest();
		
	 }
}
