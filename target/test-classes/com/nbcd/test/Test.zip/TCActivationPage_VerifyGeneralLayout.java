package com.nbcd.Test;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.codoid.products.exception.FilloException;
import com.nbcd.GenericLib.Extent_Reports;
import com.nbcd.Pages.PGActivationPage;

public class TCActivationPage_VerifyGeneralLayout extends Extent_Reports 
{
	public WebDriver driver;
	
	
	
	@Test(groups="TCActivationPage_VerifyGeneralLayout")
	@Parameters({ "Browser"})
	 public void VerifyGeneralLayout(String Browser) throws InterruptedException, FilloException, IOException 
	 {

		PGActivationPage objHP = new PGActivationPage(Browser);
		
		objHP.VerifyGeneralLayout();
		
	 }
} 
