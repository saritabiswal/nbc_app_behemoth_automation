package com.nbcd.Test;

import java.io.IOException;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.codoid.products.exception.FilloException;
import com.nbcd.GenericLib.Extent_Reports;
import com.nbcd.Pages.PGSchedulePage;
import com.nbcd.Pages.PGShowHomePage_043VerifyTwitterTags;
import com.nbcd.Pages.PGShowHomePage_VerifyThe300x250_Display_Ad;
public class TCSchedulePage_Verify_visitSiteLink  extends Extent_Reports
{
	public WebDriver driver;
	
	
	@Test(groups="TCSchedulePage_Verify_visitSiteLink")
	
	@Parameters({ "Browser"})
	 public void Verify_visitSiteLink(String Browser) throws InterruptedException, FilloException, IOException 
	 {
		
		PGSchedulePage objSP;
		try {
			objSP = new PGSchedulePage(Browser);
			objSP.Verify_visitSiteLink();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		

	}
				
	

}


	
	

