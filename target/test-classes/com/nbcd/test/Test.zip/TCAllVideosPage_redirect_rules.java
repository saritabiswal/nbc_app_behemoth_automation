package com.nbcd.Test;

import java.io.IOException;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.codoid.products.exception.FilloException;
import com.nbcd.GenericLib.Extent_Reports;
import com.nbcd.Pages.PGAllVideosPage;
import com.nbcd.Pages.PGSchedulePage;
import com.nbcd.Pages.PGShowHomePage_043VerifyTwitterTags;
import com.nbcd.Pages.PGShowHomePage_VerifyThe300x250_Display_Ad;
public class TCAllVideosPage_redirect_rules extends Extent_Reports
{
	public WebDriver driver;
	
	
	@Test(groups="TCAllVideosPage")
	
	@Parameters({ "Browser"})
	 public TCAllVideosPage_redirect_rules(String Browser) throws InterruptedException, FilloException, IOException 
	 {
		
		PGAllVideosPage objSP;
		try {
			objSP = new PGAllVideosPage(Browser);
			objSP.Verify_Page_redirect();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		

	}
				
	

}


	
	

