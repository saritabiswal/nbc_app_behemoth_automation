package com.nbcd.Test;

import java.io.IOException;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.codoid.products.exception.FilloException;
import com.nbcd.GenericLib.Extent_Reports;
import com.nbcd.Pages.PGShowHomePage_043VerifyFaceBookTags;
public class TCShowHomePage_VerifymetaTags  extends Extent_Reports
{
	public WebDriver driver;
	
	
	@Test(groups="TCShowHomePage_VerifymetaTags")
	
	@Parameters({ "Browser"})
	public void metaTags(String Browser) throws InterruptedException, FilloException, IOException 
	 {
		
		PGShowHomePage_043VerifyFaceBookTags objSP;
		try {
			objSP = new PGShowHomePage_043VerifyFaceBookTags(Browser);
			objSP.VerifymetaTags();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		

	}
				
	

}


	
	

